# Contador de Personas

Contador web de una sola página con:
- Hombres y mujeres.
- Botón +1 independiente para cada género.
- Botones para restar.
- Botón -1 Persona.
- Porcentajes y barra visual.
- Reinicio.
- Exportación del contador a TXT.
- Diseño responsive.
- Compatible con GitHub Pages.
